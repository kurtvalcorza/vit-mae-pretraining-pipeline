"""P1: fetch the 360 pinned photographs with the carried fetch_corpus (digest-checked), rebuild the seed-42
216/48/96 split, check disjointness and observer overlap, recompute the majority and colour-neighbour
baselines with the carried metrics. P3: recompute the two non-neural fills (carried mean_patch_fill / blur_fill)
on the test photographs and on the notebook's three drawn shapes, with an approximation of the processor
(224x224 bicubic resize, ImageNet mean/std, MAE (p, p, c) patch order) and numpy-seeded 75 % masks instead of
the pipeline's torch noise. The approximation is checked against the recorded photo fills before it is used."""
import json, sys, types, importlib
from pathlib import Path
import numpy as np
from PIL import Image
repo, out = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
pkg = types.ModuleType('vit_mae_pipeline'); pkg.__path__ = [str(repo / 'src/vit_mae_pipeline')]
sys.modules['vit_mae_pipeline'] = pkg
S = importlib.import_module('vit_mae_pipeline.samples')
M = importlib.import_module('vit_mae_pipeline.metrics')
files = S.fetch_corpus(cache_dir=str(out / 'inat'))
corpus = S.read_corpus(files)
splits = S.build_sample_dataset(corpus, seed=42)
man = {k: S.validate_dataset(v) for k, v in splits.items()}
splits = {k: m['records'] for k, m in man.items()}
classes = S.class_names(splits['train'])
maj = M.majority_baseline(splits['train'], splits['test'], classes)
nb = M.colour_neighbour_baseline(splits['train'], splits['test'], classes)
r = lambda d: {k: round(float(d[k]), 3) for k in ('accuracy', 'macro_f1')}
res = {'photographs': len(corpus), 'bytes': sum(len(v) for v in files.values()), 'species': list(S.SPECIES),
       'split': {k: len(v) for k, v in splits.items()}, 'disjoint': S.check_split_disjoint(splits),
       'observer_overlap': S.observer_overlap(splits), 'digests': {k: m['digest'][:12] for k, m in man.items()},
       'majority': r(maj), 'colour_neighbour': r(nb),
       'record_2026_09_21': {'majority': {'accuracy': 0.167, 'macro_f1': 0.048}, 'colour_neighbour': {'accuracy': 0.26, 'macro_f1': 0.261}}}
MEAN, STD = np.array([0.485, 0.456, 0.406]), np.array([0.229, 0.224, 0.225])
def patches(img):
    a = np.asarray(img.convert('RGB').resize((224, 224), Image.BICUBIC), dtype=np.float64) / 255.0
    a = (a - MEAN) / STD
    return a.reshape(14, 16, 14, 16, 3).transpose(0, 2, 1, 3, 4).reshape(196, 768)
def fills(images, seed=0):
    rng = np.random.default_rng(seed); mrows, brows = [], []
    for img in images:
        p = patches(img); m = np.zeros(196); m[rng.permutation(196)[:147]] = 1
        mrows.append(M.masked_mse(M.mean_patch_fill(p, m), p, m)); brows.append(M.masked_mse(M.blur_fill(p, m, grid=14), p, m))
    return np.array(mrows), np.array(brows)
mf, bf = fills([x['image'] for x in splits['test']])
res['P3_test_photo_fills_approx'] = {'mean_patch_fill': round(mf.mean(), 4), 'blur_fill': round(bf.mean(), 4),
    'record': {'mean_patch_fill': 0.7652, 'blur_fill': 0.5452, 'frozen': 0.2281}}
# the notebook's three drawn shapes, rendered exactly as cell 21 renders them
nb_cells = json.loads((repo / 'tutorials/vit_mae_pretraining_colab.ipynb').read_text())['cells']
c21 = next(''.join(c['source']) for c in nb_cells if 'def render_ppm' in ''.join(c['source']))
g = {}
exec(c21.split("Path('outputs/sample-data')")[0], g)
import io, hashlib
shapes = {}
for name, (fg, shape) in {'red_square.ppm': ((220, 40, 40), 'square'), 'green_circle.ppm': ((40, 170, 75), 'circle'), 'blue_triangle.ppm': ((40, 90, 220), 'triangle')}.items():
    ppm = g['render_ppm'](fg, shape).encode('ascii')
    assert hashlib.sha256(ppm).hexdigest() == g['SAMPLE_DIGESTS'][name]
    shapes[name] = Image.open(io.BytesIO(ppm))
per = {}
for name, img in shapes.items():
    m_, b_ = fills([img] * 20, seed=7)
    per[name] = {'mean_patch_fill_mean_over_20_masks': round(m_.mean(), 4), 'blur_fill_mean_over_20_masks': round(b_.mean(), 4),
                 'blur_fill_masks_with_zero_error': int((b_ < 1e-12).sum()), 'blur_lt_mean_masks': int((b_ < m_).sum())}
res['P3_drawn_shapes_fills_approx'] = per
res['P3_drawn_shapes_record_frozen_masked_mse'] = 'about 0.0005-0.02 (cell 20, build record)'
print(json.dumps(res, indent=1, default=str)); (out / 'p1_p3.json').write_text(json.dumps(res, indent=1, default=str))
